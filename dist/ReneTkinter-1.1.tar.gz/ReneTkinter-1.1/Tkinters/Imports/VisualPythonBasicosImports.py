#from Tkinters.VisualPython import esFrame
#from Tkinters.VisualPython import esTk

from Tkinters.VisualPythonBasicos import esFrame
from Tkinters.VisualPythonBasicos import esTk
from Tkinters.VisualPythonBasicos import esStringVar
from Tkinters.VisualPythonBasicos import append
from Tkinters.VisualPythonBasicos import esMenu
from Tkinters.VisualPythonBasicos import responderException
from Tkinters.VisualPythonBasicos import showDialogoSalir
from Tkinters.VisualPythonBasicos import showError
from Tkinters.VisualPythonBasicos import showInfo
from Tkinters.VisualPythonBasicos import showAdvertencia
from Tkinters.VisualPythonBasicos import showAceptarCancelarInf
from Tkinters.VisualPythonBasicos import showAceptarCancelarAdvertencia
from Tkinters.VisualPythonBasicos import showFileChoser
from Tkinters.VisualPythonBasicos import showDirectoryChoser
from Utiles.Utiles import *


#from Tkinters.VisualPython import esVentana
#from Tkinters.VisualPython import esFrameVentana

